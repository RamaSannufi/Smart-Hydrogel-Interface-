# Smart Hydrogel Interface

A complete monitoring UI for smart hydrogel-based treatments.
