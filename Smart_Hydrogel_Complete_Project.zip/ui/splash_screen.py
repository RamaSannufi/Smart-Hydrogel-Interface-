import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import os
import json

class SplashScreen(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Smart Hydrogel")
        self.geometry("600x400")
        self.configure(bg='#121212')
        self.overrideredirect(True)

        logo_image = Image.open("assets/logo.png")
        logo_image = logo_image.resize((150, 150))
        logo = ImageTk.PhotoImage(logo_image)
        logo_label = tk.Label(self, image=logo, bg='#121212')
        logo_label.image = logo
        logo_label.pack(pady=30)

        tk.Label(self, text="Smart Hydrogel", font=("Helvetica", 20, "bold"), bg='#121212', fg='#80cbc4').pack()
        tk.Label(self, text="Precision medicine starts here…", font=("Helvetica", 13), bg='#121212', fg='white').pack(pady=10)

        self.after(3000, self.check_first_time)

    def check_first_time(self):
        settings_path = "app_settings.json"
        if not os.path.exists(settings_path):
            with open(settings_path, 'w') as f:
                json.dump({"first_time": False}, f)
        self.destroy()
        import ui.patient_dashboard
        ui.patient_dashboard.PatientDashboard().mainloop()
