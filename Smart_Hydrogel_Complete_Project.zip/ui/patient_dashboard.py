import tkinter as tk
from tkinter import ttk, messagebox
import random
import os
from fpdf import FPDF

class PatientDashboard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Patient Dashboard")
        self.geometry("600x500")
        self.configure(bg='#121212')

        tk.Label(self, text="Welcome, Patient!", font=("Helvetica", 20, "bold"), bg='#121212', fg='#80cbc4').pack(pady=20)

        self.readings = {
            "pH Level": f"{random.uniform(6.5, 7.5):.2f}",
            "Temperature": f"{random.uniform(36.0, 39.5):.1f}°C",
            "Glucose Level": f"{random.randint(80, 180)} mg/dL"
        }

        for key, value in self.readings.items():
            tk.Label(self, text=f"{key}: {value}", font=("Helvetica", 12), bg='#121212', fg='white').pack()

        ttk.Button(self, text="Export Report", command=self.export_pdf_report).pack(pady=20)

    def export_pdf_report(self):
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.cell(200, 10, txt="Smart Hydrogel - Medical Report", ln=True, align='C')
        pdf.ln(10)
        pdf.cell(200, 10, txt="Condition: Cancer", ln=True)
        pdf.cell(200, 10, txt="Hydrogel: pH-sensitive", ln=True)
        pdf.cell(200, 10, txt="Start Date: 20/05/2025", ln=True)
        pdf.cell(200, 10, txt=f"pH Level: {self.readings['pH Level']}", ln=True)
        pdf.cell(200, 10, txt=f"Temperature: {self.readings['Temperature']}", ln=True)
        pdf.cell(200, 10, txt=f"Glucose Level: {self.readings['Glucose Level']}", ln=True)

        placeholder_chart = "assets/placeholder_chart.png"
        if os.path.exists(placeholder_chart):
            pdf.image(placeholder_chart, x=10, y=100, w=180)

        pdf.output("medical_report.pdf")
        messagebox.showinfo("Report Saved", "PDF medical report generated successfully.")
