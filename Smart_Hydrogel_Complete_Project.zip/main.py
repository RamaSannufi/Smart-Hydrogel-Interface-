import ui.splash_screen

if __name__ == '__main__':
    ui.splash_screen.SplashScreen().mainloop()
